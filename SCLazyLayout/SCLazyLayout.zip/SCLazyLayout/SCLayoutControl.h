//
//  SCLayoutControl.h
//  SCLazyLayoutSample
//
//  Created by git on 2017/3/17.
//  Copyright © 2017年 git. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCLayoutControl : UIButton

@end
